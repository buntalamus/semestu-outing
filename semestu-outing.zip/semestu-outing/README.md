# SEMESTU-Outing
This archive contains backend and frontend skeleton. Replace placeholders with real files.
